App({
  onLaunch() {
    console.log('脑电数据接收器启动')
  },
  globalData: {
    isConnected: false,
    deviceName: '',
    dataBuffer: [],
    isSimulating: false,
    simFrequency: 10,
    sampleRate: 250
  }
})
