const app = getApp()

Page({
  data: {
    isStimulating: false,
    statusText: '未开始',
    sampleCount: 0,
    recognitionCount: 0,
    currentCommand: '',
    confidence: 0,
    responseTime: 0,
    frequencies: [8, 10, 12, 15],
    flickerColors: ['#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4'],
    resultColors: ['#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4'],
    probabilities: [
      { label: 1, value: 0, color: '#ff6b6b' },
      { label: 2, value: 0, color: '#4ecdc4' },
      { label: 3, value: 0, color: '#45b7d1' },
      { label: 4, value: 0, color: '#96ceb4' }
    ],
    dataBuffer: [],
    bufferSize: 1024,
    sampleRate: 256,
    recognitionTimer: null,
    monitorTimer: null,
    startTime: 0,
    globalSimulating: false,
    globalBufferLength: 0,
    simFrequency: 0,
    latestData: [],
    lastUpdateTime: '',
    lastGlobalDataIndex: 0
  },

  onLoad() {
    console.log('[SSVEP] 页面加载')
    this.initBluetooth()
    this.startMonitoringGlobalData()
  },

  onShow() {
    console.log('[SSVEP] 页面显示')
    console.log('[SSVEP] 全局模拟状态:', app.globalData.isSimulating)
    console.log('[SSVEP] 全局数据缓冲区长度:', app.globalData.dataBuffer.length)
    console.log('[SSVEP] 全局模拟频率:', app.globalData.simFrequency, 'Hz')
  },

  onHide() {
    console.log('[SSVEP] 页面隐藏')
  },

  onUnload() {
    console.log('[SSVEP] 页面卸载')
    this.stopStimulation()
    this.stopMonitoringGlobalData()
  },

  initBluetooth() {
    wx.openBluetoothAdapter({
      success: () => {
        this.setData({ statusText: '蓝牙已就绪' })
        this.startBluetoothDevicesDiscovery()
      },
      fail: (err) => {
        console.error('蓝牙初始化失败', err)
        wx.showToast({
          title: '请开启蓝牙',
          icon: 'none'
        })
      }
    })
  },

  startBluetoothDevicesDiscovery() {
    wx.startBluetoothDevicesDiscovery({
      allowDuplicatesKey: true,
      success: () => {
        this.onBluetoothDeviceFound()
      }
    })
  },

  onBluetoothDeviceFound() {
    wx.onBluetoothDeviceFound((res) => {
      console.log('发现设备', res)
    })
  },

  connectDevice() {
    wx.showLoading({ title: '正在搜索设备...' })

    wx.startBluetoothDevicesDiscovery({
      allowDuplicatesKey: true,
      success: () => {
        setTimeout(() => {
          wx.getBluetoothDevices({
            success: (res) => {
              wx.hideLoading()
              const devices = res.devices
              if (devices.length === 0) {
                wx.showToast({ title: '未发现设备', icon: 'none' })
                return
              }

              const deviceNames = devices.map(d => d.name || d.localName || '未知设备')
              wx.showActionSheet({
                itemList: deviceNames,
                success: (res) => {
                  this.connectToDevice(devices[res.tapIndex].deviceId)
                }
              })
            }
          })
        }, 2000)
      }
    })
  },

  connectToDevice(deviceId) {
    wx.showLoading({ title: '正在连接...' })

    wx.createBLEConnection({
      deviceId: deviceId,
      success: (res) => {
        wx.stopBluetoothDevicesDiscovery()
        this.setData({ statusText: '已连接' })
        this.getServices(deviceId)
      },
      fail: (err) => {
        wx.hideLoading()
        wx.showToast({ title: '连接失败', icon: 'none' })
      }
    })
  },

  getServices(deviceId) {
    wx.getBLEDeviceServices({
      deviceId: deviceId,
      success: (res) => {
        const services = res.services
        for (let service of services) {
          this.getCharacteristics(deviceId, service.uuid)
        }
      }
    })
  },

  getCharacteristics(deviceId, serviceId) {
    wx.getBLEDeviceCharacteristics({
      deviceId: deviceId,
      serviceId: serviceId,
      success: (res) => {
        const characteristics = res.characteristics
        for (let char of characteristics) {
          if (char.properties.notify || char.properties.read) {
            this.notifyCharacteristicValueChange(deviceId, serviceId, char.uuid)
          }
        }
      }
    })
  },

  notifyCharacteristicValueChange(deviceId, serviceId, characteristicId) {
    wx.notifyBLECharacteristicValueChange({
      deviceId: deviceId,
      serviceId: serviceId,
      characteristicId: characteristicId,
      state: true,
      success: () => {
        this.onBLECharacteristicValueChange()
      }
    })
  },

  onBLECharacteristicValueChange() {
    wx.onBLECharacteristicValueChange((res) => {
      if (this.data.isStimulating) {
        this.processData(res.value)
      }
    })
  },

  processData(buffer) {
    const data = new Uint8Array(buffer)
    const dataBuffer = this.data.dataBuffer

    for (let i = 0; i < data.length; i += 2) {
      if (i + 1 < data.length) {
        const rawValue = (data[i + 1] << 8) | data[i]
        const voltage = (rawValue / 32768) * 3.3
        dataBuffer.push(voltage)

        if (dataBuffer.length > this.data.bufferSize) {
          dataBuffer.shift()
        }
      }
    }

    this.setData({
      dataBuffer: dataBuffer,
      sampleCount: dataBuffer.length
    })
  },

  startStimulation() {
    if (!this.data.isStimulating) {
      console.log('[SSVEP] 开始刺激，初始化数据')
      console.log('[SSVEP] 全局缓冲区长度:', app.globalData.dataBuffer.length)
      
      const initialData = [...app.globalData.dataBuffer]
      
      this.setData({
        isStimulating: true,
        statusText: '闪烁中...',
        dataBuffer: initialData,
        sampleCount: initialData.length,
        sampleRate: app.globalData.sampleRate || 256,
        startTime: Date.now(),
        lastGlobalDataIndex: app.globalData.dataBuffer.length
      })

      console.log('[SSVEP] 初始化完成，lastGlobalDataIndex:', this.data.lastGlobalDataIndex)

      this.startFlickerAnimation()
      this.startRecognition()
      
      if (app.globalData.isSimulating) {
        this.setData({ statusText: '使用模拟数据' })
      } else {
        this.connectDevice()
      }
    }
  },

  stopStimulation() {
    if (this.data.isStimulating) {
      this.setData({
        isStimulating: false,
        statusText: '已停止'
      })

      this.stopFlickerAnimation()
      this.stopRecognition()
    }
  },

  startFlickerAnimation() {
    console.log('开始闪烁动画')
  },

  stopFlickerAnimation() {
    console.log('停止闪烁动画')
  },

  startRecognition() {
    console.log('[识别] 启动识别定时器')
    this.data.recognitionTimer = setInterval(() => {
      console.log('[识别定时器] 检查数据，当前长度:', this.data.dataBuffer.length, '需要长度:', this.data.bufferSize, 'isStimulating:', this.data.isStimulating)
      if (this.data.dataBuffer.length >= this.data.bufferSize) {
        console.log('[识别定时器] 数据足够，开始识别')
        this.recognizeSSVEP()
      }
    }, 500)
  },

  stopRecognition() {
    if (this.data.recognitionTimer) {
      clearInterval(this.data.recognitionTimer)
      this.data.recognitionTimer = null
    }
  },

  recognizeSSVEP() {
    console.log('[识别] 开始识别，当前时间:', new Date().toLocaleTimeString())
    const startTime = Date.now()
    
    const dataBuffer = this.data.dataBuffer
    const frequencies = this.data.frequencies
    const sampleRate = this.data.sampleRate

    console.log('========== 识别算法调用 ==========')
    console.log('数据缓冲区长度:', dataBuffer.length)
    console.log('采样率:', sampleRate)
    console.log('前10个数据点:', dataBuffer.slice(0, 10).map(v => v.toFixed(4)))
    console.log('后10个数据点:', dataBuffer.slice(-10).map(v => v.toFixed(4)))

    if (dataBuffer.length < 256) {
      console.log('数据不足，跳过识别')
      return
    }

    const spectrum = this.fft(dataBuffer, sampleRate)
    console.log('FFT频谱分析:')
    frequencies.forEach(freq => {
      const idx = Math.round(freq * dataBuffer.length / sampleRate)
      const magnitude = spectrum[idx] || 0
      console.log(`  ${freq}Hz: 幅度 = ${magnitude.toFixed(4)}`)
    })

    const results = this.fbcca(dataBuffer, frequencies, sampleRate)

    console.log('FBCCA识别结果:', results.map((r, i) => `${frequencies[i]}Hz: ${(r*100).toFixed(2)}%`))

    const maxIndex = results.indexOf(Math.max(...results))
    const confidence = (results[maxIndex] * 100).toFixed(2)
    const responseTime = Date.now() - this.data.startTime

    console.log(`识别结果: 指令${maxIndex + 1} (${frequencies[maxIndex]}Hz), 置信度: ${confidence}%`)
    console.log('====================================')
    console.log('[识别] 识别完成，耗时:', Date.now() - startTime, 'ms')

    this.setData({
      currentCommand: `指令${maxIndex + 1}`,
      confidence: confidence,
      responseTime: responseTime,
      recognitionCount: this.data.recognitionCount + 1,
      probabilities: this.data.probabilities.map((item, index) => ({
        ...item,
        value: (results[index] * 100).toFixed(2)
      }))
    }, () => {
      console.log('[识别结果] setData回调执行完成，isStimulating:', this.data.isStimulating)
    })
  },

  fbcca(data, frequencies, sampleRate) {
    console.log('========== FBCCA算法详细分析 ==========')
    console.log('数据长度:', data.length, '采样率:', sampleRate)
    console.log('数据统计 - 均值:', this.mean(data).toFixed(4), '标准差:', this.std(data).toFixed(4))
    console.log('数据范围 - 最小值:', Math.min(...data).toFixed(4), '最大值:', Math.max(...data).toFixed(4))
    
    const numBands = 5
    const bandEdges = [6, 14, 22, 30, 38, 90]
    const results = []

    for (let freq of frequencies) {
      console.log(`\n--- 处理频率 ${freq}Hz ---`)
      let totalCorrelation = 0
      const bandCorrelations = []

      for (let band = 0; band < numBands; band++) {
        const lowcut = bandEdges[band]
        const highcut = bandEdges[band + 1]
        
        console.log(`  频带 ${band}: ${lowcut}-${highcut}Hz`)
        
        const filteredData = this.butterworthFilter(data, lowcut, highcut, sampleRate, 4)
        console.log(`  滤波后统计 - 均值: ${this.mean(filteredData).toFixed(4)}, 标准差: ${this.std(filteredData).toFixed(4)}`)

        const correlation = this.cca(filteredData, freq, sampleRate)
        console.log(`  频带总相关性: ${correlation.toFixed(4)}`)
        
        bandCorrelations.push(correlation)
        
        if (!isNaN(correlation) && isFinite(correlation)) {
          totalCorrelation += Math.pow(correlation, 2)
        }
      }

      const result = Math.sqrt(totalCorrelation / numBands)
      results.push(result)
      console.log(`频率 ${freq}Hz 的最终结果: ${result.toFixed(4)}`)
      console.log(`各频带相关性: [${bandCorrelations.map(r => r.toFixed(4)).join(', ')}]`)
    }

    console.log('\n--- 最终结果对比 ---')
    frequencies.forEach((freq, i) => {
      console.log(`${freq}Hz: ${results[i].toFixed(4)} (${(results[i] * 100).toFixed(2)}%)`)
    })

    const sum = results.reduce((a, b) => a + b, 0)
    
    let normalizedResults
    if (sum > 0) {
      normalizedResults = results.map(r => r / sum)
    } else {
      normalizedResults = results.map(() => 0.25)
      console.log('警告: 所有频率的相关性为0，使用均匀分布')
    }
    
    console.log('归一化后的结果:', normalizedResults.map((r, i) => `${frequencies[i]}Hz: ${(r * 100).toFixed(2)}%`).join(', '))
    console.log('=====================================\n')
    
    return normalizedResults
  },

  butterworthFilter(data, lowcut, highcut, fs, order) {
    const nyquist = 0.5 * fs
    const low = lowcut / nyquist
    const high = highcut / nyquist

    console.log(`    滤波器参数 - 采样率: ${fs}Hz, 截止频率: ${lowcut}-${highcut}Hz, 归一化: ${low.toFixed(3)}-${high.toFixed(3)}`)

    const filtered = this.simpleBandpassFilter(data, low, high)

    console.log(`    滤波后统计 - 均值: ${this.mean(filtered).toFixed(4)}, 标准差: ${this.std(filtered).toFixed(4)}`)

    return filtered
  },

  simpleBandpassFilter(data, low, high) {
    const n = data.length
    const filtered = new Array(n).fill(0)
    
    const centerFreq = (low + high) / 2
    const bandwidth = high - low
    
    const alpha = Math.min(0.3, bandwidth * 0.5)
    const beta = Math.min(0.15, bandwidth * 0.25)
    
    filtered[0] = data[0]
    filtered[1] = data[1]
    
    for (let i = 2; i < n; i++) {
      const lowPass = alpha * data[i] + (1 - alpha) * filtered[i - 1]
      const highPass = beta * (lowPass - filtered[i - 2]) + (1 - beta) * filtered[i - 1]
      filtered[i] = highPass
    }
    
    console.log(`    滤波器参数 - 中心频率: ${centerFreq.toFixed(3)}, 带宽: ${bandwidth.toFixed(3)}, alpha: ${alpha.toFixed(3)}, beta: ${beta.toFixed(3)}`)
    
    return filtered
  },

  mean(data) {
    return data.reduce((a, b) => a + b, 0) / data.length
  },

  std(data) {
    const mean = this.mean(data)
    return Math.sqrt(data.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / data.length)
  },

  cca(data, freq, sampleRate) {
    const referenceSignals = this.generateReferenceSignals(data.length, freq, sampleRate)

    const x = this.normalize(data)
    
    let totalCorrelation = 0
    
    for (let harmonic = 1; harmonic <= 3; harmonic++) {
      const y1 = this.normalize(referenceSignals[(harmonic - 1) * 2])
      const y2 = this.normalize(referenceSignals[(harmonic - 1) * 2 + 1])

      const corr1 = this.correlation(x, y1)
      const corr2 = this.correlation(x, y2)
      
      const harmonicCorrelation = Math.sqrt(corr1 * corr1 + corr2 * corr2)
      totalCorrelation += harmonicCorrelation
      
      console.log(`    谐波${harmonic} (${freq * harmonic}Hz): 相关性 = ${harmonicCorrelation.toFixed(4)}`)
    }

    return totalCorrelation / 3
  },

  generateReferenceSignals(length, freq, sampleRate) {
    const signals = []

    for (let harmonic = 1; harmonic <= 3; harmonic++) {
      const sinSignal = []
      const cosSignal = []

      for (let i = 0; i < length; i++) {
        const t = i / sampleRate
        sinSignal.push(Math.sin(2 * Math.PI * freq * harmonic * t))
        cosSignal.push(Math.cos(2 * Math.PI * freq * harmonic * t))
      }

      signals.push(sinSignal)
      signals.push(cosSignal)
    }

    return signals
  },

  normalize(data) {
    const mean = data.reduce((a, b) => a + b, 0) / data.length
    const std = Math.sqrt(data.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / data.length)

    return data.map(val => (val - mean) / (std || 1))
  },

  correlation(x, y) {
    const n = x.length
    let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0, sumY2 = 0

    for (let i = 0; i < n; i++) {
      sumX += x[i]
      sumY += y[i]
      sumXY += x[i] * y[i]
      sumX2 += x[i] * x[i]
      sumY2 += y[i] * y[i]
    }

    const numerator = n * sumXY - sumX * sumY
    const denominator = Math.sqrt((n * sumX2 - sumX * sumX) * (n * sumY2 - sumY * sumY))

    return denominator === 0 ? 0 : numerator / denominator
  },

  startMonitoringGlobalData() {
    console.log('[SSVEP] 开始监控全局数据')
    console.log('[SSVEP] 监控间隔: 200ms')
    
    this.data.monitorTimer = setInterval(() => {
      const globalSimulating = app.globalData.isSimulating
      const globalBufferLength = app.globalData.dataBuffer.length
      const simFrequency = app.globalData.simFrequency
      const isStimulating = this.data.isStimulating
      
      console.log(`[SSVEP监控] 全局模拟: ${globalSimulating}, SSVEP刺激: ${isStimulating}`)
      console.log(`[SSVEP监控] 全局缓冲区长度: ${globalBufferLength}, 上次读取位置: ${this.data.lastGlobalDataIndex}`)
      
      this.setData({
        globalSimulating,
        globalBufferLength,
        simFrequency
      })
      
      if (globalSimulating && isStimulating) {
        const globalData = app.globalData.dataBuffer
        
        if (globalData.length === 0) {
          console.log('[SSVEP] 警告: 全局数据缓冲区为空!')
          return
        }
        
        const lastGlobalDataIndex = this.data.lastGlobalDataIndex
        const newDataCount = globalData.length - lastGlobalDataIndex
        
        console.log(`[SSVEP] 全局数据缓冲区长度: ${globalData.length}`)
        console.log(`[SSVEP] 上次读取位置: ${lastGlobalDataIndex}, 新数据点数: ${newDataCount}`)
        
        if (newDataCount > 0) {
          const newData = globalData.slice(lastGlobalDataIndex)
          const currentBuffer = [...this.data.dataBuffer]
          
          console.log(`[SSVEP] 本地数据缓冲区更新前长度: ${currentBuffer.length}`)
          console.log(`[SSVEP] 新数据前5个值: ${newData.slice(0, 5).map(v => v.toFixed(4)).join(', ')}`)
          
          for (let value of newData) {
            currentBuffer.push(value)
            if (currentBuffer.length > this.data.bufferSize) {
              currentBuffer.shift()
            }
          }
          
          console.log(`[SSVEP] 本地数据缓冲区更新后长度: ${currentBuffer.length}`)
          
          const latestData = currentBuffer.slice(-10).map(v => v.toFixed(4))
          const now = new Date()
          const lastUpdateTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}.${now.getMilliseconds().toString().padStart(3, '0')}`
          
          console.log(`[SSVEP] 准备更新UI - 本地缓冲区: ${currentBuffer.length}, 最新数据: ${latestData.slice(0, 3).join(', ')}`)
          
          this.setData({
            dataBuffer: currentBuffer,
            sampleCount: currentBuffer.length,
            latestData,
            lastUpdateTime,
            lastGlobalDataIndex: globalData.length
          }, () => {
            console.log(`[SSVEP] setData回调执行完成`)
            console.log(`[SSVEP] 更新后的data.latestData:`, this.data.latestData)
            console.log(`[SSVEP] 更新后的data.lastUpdateTime:`, this.data.lastUpdateTime)
          })
          
          console.log(`[SSVEP] UI更新完成，新的读取位置: ${globalData.length}`)
        } else {
          console.log(`[SSVEP] 没有新数据`)
        }
      } else if (!globalSimulating) {
        console.log('[SSVEP] 全局模拟已停止，不更新数据')
      } else if (!isStimulating) {
        console.log('[SSVEP] SSVEP刺激未开始，不更新数据')
      }
    }, 200)
  },

  stopMonitoringGlobalData() {
    if (this.data.monitorTimer) {
      clearInterval(this.data.monitorTimer)
      this.data.monitorTimer = null
    }
  },

  fft(data, sampleRate) {
    const N = data.length
    const spectrum = new Array(Math.floor(N / 2)).fill(0)

    for (let k = 0; k < Math.floor(N / 2); k++) {
      let real = 0
      let imag = 0

      for (let n = 0; n < N; n++) {
        const angle = (2 * Math.PI * k * n) / N
        real += data[n] * Math.cos(angle)
        imag -= data[n] * Math.sin(angle)
      }

      spectrum[k] = Math.sqrt(real * real + imag * imag) / N
    }

    return spectrum
  }
})
