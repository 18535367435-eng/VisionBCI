const app = getApp()

Page({
  data: {
    isConnected: false,
    isSimulating: false,
    statusText: '未连接',
    deviceName: '',
    sampleRate: '-',
    dataPoints: 0,
    currentValue: '-',
    dataBuffer: [],
    maxDataPoints: 500,
    canvas: null,
    ctx: null,
    canvasWidth: 0,
    canvasHeight: 0,
    adapter: null,
    deviceId: null,
    serviceId: null,
    characteristicId: null,
    simFrequency: 10,
    simTimer: null,
    simSampleRate: 250,
    simTime: 0
  },

  onLoad() {
    this.initCanvas()
  },

  onReady() {
    this.initBluetooth()
  },

  onUnload() {
    this.disconnectDevice()
  },

  initBluetooth() {
    wx.openBluetoothAdapter({
      success: (res) => {
        console.log('蓝牙初始化成功', res)
        this.setData({ statusText: '蓝牙已就绪' })
        this.startBluetoothDevicesDiscovery()
      },
      fail: (err) => {
        console.error('蓝牙初始化失败', err)
        wx.showToast({
          title: '请开启蓝牙',
          icon: 'none'
        })
      }
    })
  },

  startBluetoothDevicesDiscovery() {
    wx.startBluetoothDevicesDiscovery({
      allowDuplicatesKey: true,
      success: (res) => {
        console.log('开始搜索设备')
        this.onBluetoothDeviceFound()
      },
      fail: (err) => {
        console.error('搜索设备失败', err)
      }
    })
  },

  onBluetoothDeviceFound() {
    wx.onBluetoothDeviceFound((res) => {
      console.log('发现设备', res)
    })
  },

  connectDevice() {
    wx.showLoading({
      title: '正在搜索设备...'
    })

    wx.startBluetoothDevicesDiscovery({
      allowDuplicatesKey: true,
      success: () => {
        setTimeout(() => {
          wx.getBluetoothDevices({
            success: (res) => {
              wx.hideLoading()
              const devices = res.devices
              if (devices.length === 0) {
                wx.showToast({
                  title: '未发现设备',
                  icon: 'none'
                })
                return
              }

              const deviceNames = devices.map(d => d.name || d.localName || '未知设备')
              wx.showActionSheet({
                itemList: deviceNames,
                success: (res) => {
                  const device = devices[res.tapIndex]
                  this.connectToDevice(device.deviceId)
                }
              })
            }
          })
        }, 2000)
      }
    })
  },

  connectToDevice(deviceId) {
    wx.showLoading({
      title: '正在连接...'
    })

    wx.createBLEConnection({
      deviceId: deviceId,
      success: (res) => {
        console.log('连接成功', res)
        this.setData({ 
          deviceId: deviceId,
          statusText: '已连接'
        })
        
        wx.stopBluetoothDevicesDiscovery()
        
        this.getServices(deviceId)
      },
      fail: (err) => {
        console.error('连接失败', err)
        wx.hideLoading()
        wx.showToast({
          title: '连接失败',
          icon: 'none'
        })
      }
    })
  },

  getServices(deviceId) {
    wx.getBLEDeviceServices({
      deviceId: deviceId,
      success: (res) => {
        console.log('获取服务成功', res)
        const services = res.services
        
        for (let service of services) {
          this.getCharacteristics(deviceId, service.uuid)
        }
      },
      fail: (err) => {
        console.error('获取服务失败', err)
        wx.hideLoading()
      }
    })
  },

  getCharacteristics(deviceId, serviceId) {
    wx.getBLEDeviceCharacteristics({
      deviceId: deviceId,
      serviceId: serviceId,
      success: (res) => {
        console.log('获取特征值成功', res)
        const characteristics = res.characteristics
        
        for (let char of characteristics) {
          if (char.properties.notify || char.properties.read) {
            this.setData({
              serviceId: serviceId,
              characteristicId: char.uuid
            })
            
            this.notifyCharacteristicValueChange(deviceId, serviceId, char.uuid)
            
            wx.getBLEDeviceName({
              deviceId: deviceId,
              success: (res) => {
                this.setData({ 
                  deviceName: res.name,
                  isConnected: true
                })
                wx.hideLoading()
              }
            })
          }
        }
      }
    })
  },

  notifyCharacteristicValueChange(deviceId, serviceId, characteristicId) {
    wx.notifyBLECharacteristicValueChange({
      deviceId: deviceId,
      serviceId: serviceId,
      characteristicId: characteristicId,
      state: true,
      success: (res) => {
        console.log('启用通知成功', res)
        this.onBLECharacteristicValueChange()
      }
    })
  },

  onBLECharacteristicValueChange() {
    wx.onBLECharacteristicValueChange((res) => {
      console.log('收到数据', res)
      this.processData(res.value)
    })
  },

  processData(buffer) {
    const data = new Uint8Array(buffer)
    
    for (let i = 0; i < data.length; i += 2) {
      if (i + 1 < data.length) {
        const rawValue = (data[i + 1] << 8) | data[i]
        const voltage = (rawValue / 32768) * 3.3
        this.addDataPoint(voltage)
      }
    }
  },

  addDataPoint(value) {
    const dataBuffer = this.data.dataBuffer
    dataBuffer.push(value)
    
    if (dataBuffer.length > this.data.maxDataPoints) {
      dataBuffer.shift()
    }
    
    this.setData({
      dataBuffer: dataBuffer,
      dataPoints: dataBuffer.length,
      currentValue: dataBuffer.length > 0 ? dataBuffer[dataBuffer.length - 1].toFixed(4) : '-',
      sampleRate: '256'
    })
    
    this.drawWaveform()
  },

  disconnectDevice() {
    if (this.data.deviceId) {
      wx.closeBLEConnection({
        deviceId: this.data.deviceId,
        success: () => {
          console.log('断开连接成功')
          this.setData({
            isConnected: false,
            statusText: '未连接',
            deviceName: '',
            deviceId: null,
            serviceId: null,
            characteristicId: null
          })
        }
      })
    }
  },

  clearData() {
    this.setData({
      dataBuffer: [],
      dataPoints: 0,
      currentValue: '-'
    })
    this.drawWaveform()
  },

  goToSSVEP() {
    wx.navigateTo({
      url: '/pages/ssvep/ssvep'
    })
  },

  initCanvas() {
    const query = wx.createSelectorQuery()
    query.select('#eegCanvas')
      .fields({ node: true, size: true })
      .exec((res) => {
        if (res[0]) {
          const canvas = res[0].node
          const ctx = canvas.getContext('2d')
          
          const dpr = wx.getSystemInfoSync().pixelRatio
          canvas.width = res[0].width * dpr
          canvas.height = res[0].height * dpr
          ctx.scale(dpr, dpr)
          
          this.setData({
            canvas: canvas,
            ctx: ctx,
            canvasWidth: res[0].width,
            canvasHeight: res[0].height
          })
          
          this.drawWaveform()
        }
      })
  },

  onSimFrequencyChange(e) {
    const frequency = parseFloat(e.detail.value)
    if (frequency > 0) {
      this.setData({ simFrequency: frequency })
    }
  },

  startSimulation() {
    if (this.data.isSimulating) return

    console.log('========== 开始模拟数据生成 ==========')
    console.log('模拟频率:', this.data.simFrequency, 'Hz')
    console.log('采样率:', this.data.simSampleRate, 'Hz')
    console.log('======================================')

    app.globalData.isSimulating = true
    app.globalData.simFrequency = this.data.simFrequency
    app.globalData.sampleRate = this.data.simSampleRate
    app.globalData.dataBuffer = []

    this.setData({
      isSimulating: true,
      statusText: '模拟数据生成中',
      deviceName: '模拟信号',
      sampleRate: this.data.simSampleRate,
      simTime: 0,
      dataBuffer: []
    })

    const interval = 1000 / this.data.simSampleRate
    this.data.simTimer = setInterval(() => {
      this.generateSimulatedData()
    }, interval)
  },

  stopSimulation() {
    if (!this.data.isSimulating) return

    if (this.data.simTimer) {
      clearInterval(this.data.simTimer)
      this.data.simTimer = null
    }

    app.globalData.isSimulating = false
    app.globalData.dataBuffer = []

    this.setData({
      isSimulating: false,
      statusText: '未连接',
      deviceName: ''
    })
  },

  generateSimulatedData() {
    if (!this.data.isSimulating) return
    
    const frequency = this.data.simFrequency
    const sampleRate = this.data.simSampleRate
    const time = this.data.simTime

    const signal = Math.sin(2 * Math.PI * frequency * time)
    const noise = (Math.random() - 0.5) * 0.05
    const voltage = signal + noise

    this.addDataPoint(voltage)

    app.globalData.dataBuffer.push(voltage)
    if (app.globalData.dataBuffer.length > 4096) {
      app.globalData.dataBuffer.shift()
    }

    if (app.globalData.dataBuffer.length % 250 === 0) {
      console.log(`[模拟数据] 时间: ${time.toFixed(2)}s, 信号: ${signal.toFixed(4)}, 最终值: ${voltage.toFixed(4)}`)
      console.log(`[模拟数据] 全局缓冲区长度: ${app.globalData.dataBuffer.length}`)
      console.log(`[模拟数据] 最近10个值: ${app.globalData.dataBuffer.slice(-10).map(v => v.toFixed(4)).join(', ')}`)
    }

    this.data.simTime = time + 1 / sampleRate
  },

  drawWaveform() {
    const { ctx, canvasWidth, canvasHeight, dataBuffer, maxDataPoints } = this.data
    
    if (!ctx) return
    
    ctx.fillStyle = '#1a1a2e'
    ctx.fillRect(0, 0, canvasWidth, canvasHeight)
    
    ctx.strokeStyle = '#4a4a6a'
    ctx.lineWidth = 1
    
    const gridLines = 10
    for (let i = 0; i <= gridLines; i++) {
      const y = (canvasHeight / gridLines) * i
      ctx.beginPath()
      ctx.moveTo(0, y)
      ctx.lineTo(canvasWidth, y)
      ctx.stroke()
    }
    
    const verticalLines = 20
    for (let i = 0; i <= verticalLines; i++) {
      const x = (canvasWidth / verticalLines) * i
      ctx.beginPath()
      ctx.moveTo(x, 0)
      ctx.lineTo(x, canvasHeight)
      ctx.stroke()
    }
    
    if (dataBuffer.length < 2) {
      return
    }
    
    ctx.strokeStyle = '#00ff88'
    ctx.lineWidth = 2
    ctx.beginPath()
    
    const stepX = canvasWidth / maxDataPoints
    const centerY = canvasHeight / 2
    const scaleY = canvasHeight / 4
    
    for (let i = 0; i < dataBuffer.length; i++) {
      const x = i * stepX
      const y = centerY - (dataBuffer[i] * scaleY)
      
      if (i === 0) {
        ctx.moveTo(x, y)
      } else {
        ctx.lineTo(x, y)
      }
    }
    
    ctx.stroke()
    
    ctx.strokeStyle = '#ff6b6b'
    ctx.setLineDash([5, 5])
    ctx.beginPath()
    ctx.moveTo(0, centerY)
    ctx.lineTo(canvasWidth, centerY)
    ctx.stroke()
    ctx.setLineDash([])
  }
})
